export const setBooks = books => ({
  type: 'SET_BOOKS',
  payload: books
});
